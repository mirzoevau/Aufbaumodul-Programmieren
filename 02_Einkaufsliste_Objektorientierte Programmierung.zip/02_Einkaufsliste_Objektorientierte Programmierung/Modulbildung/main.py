import einkaufsliste

def main():
    # Erstellen einer Instanz der erweiterten Einkaufsliste
    meine_einkaufsliste = einkaufsliste.ErweiterteEinkaufsliste()

    while True:
        # Menü anzeigen und Benutzer zur Auswahl auffordern
        meine_einkaufsliste.zeige_menü()
        auswahl = input("Wählen Sie eine Option (1-9): ")

        if auswahl == '1':
            meine_einkaufsliste.artikel_anzeigen()
        elif auswahl == '2':
            meine_einkaufsliste.artikel_hinzufügen()
        elif auswahl == '3':
            meine_einkaufsliste.artikel_bearbeiten()
        elif auswahl == '4':
            meine_einkaufsliste.artikel_entfernen()
        elif auswahl == '5':
            meine_einkaufsliste.artikel_sortieren()
        elif auswahl == '6':
            meine_einkaufsliste.einkaufsliste_leeren()
        elif auswahl == '7':
            meine_einkaufsliste.statistik_anzeigen()
        elif auswahl == '8':
            meine_einkaufsliste.artikel_suchen()
        elif auswahl == '9':
            print("Programm beendet.")
            break
        else:
            print("Ungültige Auswahl. Bitte versuchen Sie es erneut.\n")

if __name__ == "__main__":
    main()
