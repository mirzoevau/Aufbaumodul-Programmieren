'''
Packetbildung/
│
├── einkaufsliste_paket/
│   ├── __init__.py        # Kennzeichnet das Verzeichnis als Python-Paket und ermöglicht den Import von Modulen
│   └── einkaufsliste.py   # Das Modul: Enthält die Klassen und Funktionen für die Einkaufsliste
│
└── main.py                # Startet das Programm und verwendet die Funktionen aus dem Paket

'''

# main.py
from einkaufsliste_paket.einkaufsliste import ErweiterteEinkaufsliste

def main():
    einkaufsliste = ErweiterteEinkaufsliste()

    while True:
        einkaufsliste.zeige_menü()
        auswahl = input("Wählen Sie eine Option (1-9): ")

        if auswahl == '1':
            einkaufsliste.artikel_anzeigen()
        elif auswahl == '2':
            einkaufsliste.artikel_hinzufügen()
        elif auswahl == '3':
            einkaufsliste.artikel_bearbeiten()
        elif auswahl == '4':
            einkaufsliste.artikel_entfernen()
        elif auswahl == '5':
            einkaufsliste.artikel_sortieren()
        elif auswahl == '6':
            einkaufsliste.einkaufsliste_leeren()
        elif auswahl == '7':
            einkaufsliste.statistik_anzeigen()
        elif auswahl == '8':
            einkaufsliste.artikel_suchen()
        elif auswahl == '9':
            print("Programm beendet.")
            break
        else:
            print("Ungültige Auswahl. Bitte versuchen Sie es erneut.\n")

if __name__ == "__main__":
    main()

