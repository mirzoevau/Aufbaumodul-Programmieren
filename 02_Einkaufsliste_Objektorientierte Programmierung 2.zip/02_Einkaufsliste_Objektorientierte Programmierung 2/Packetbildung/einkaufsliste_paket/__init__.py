# Diese Datei macht den Ordner einkaufsliste_paket zu einem Python-Paket, das importiert werden kann.
# einkaufsliste_paket/__init__.py

