'''
Macromedia Python-Projekt 2: OOP Programmierung
Einkaufsliste Assistent

Hier sind die wesentlichen Änderungen und Ergänzungen gegenüber dem ursprünglichen funktionsorientierten Projekt:

1. Ersetzung von CSV durch JSON
CSV-Operationen wurden durch JSON-Operationen ersetzt. JSON ist ein flexibleres Format für komplexe Datenstrukturen.

2. Umstellung auf objektorientierte Programmierung (OOP)
Die Funktionen, die im ursprünglichen Code als separate Funktionen existierten, wurden in eine Klasse namens Einkaufsliste umgewandelt. 
Diese Klasse kapselt die Funktionalitäten in einer logischen Einheit und strukturiert den Code. Zusätzlich wurde eine Vererbungshierarchie eingeführt: 
Die Klasse Einkaufsliste dient als Basisklasse und wurde um eine abgeleitete Klasse namens ErweiterteEinkaufsliste ergänzt. 
Diese abgeleitete Klasse erweitert die Basisklasse um zusätzliche Funktionalitäten wie das Sortieren der Liste, das Anzeigen von Statistiken und die Suche nach Artikeln. 
Durch diese Vererbung wurde die Wiederverwendbarkeit und Erweiterbarkeit des Codes verbessert.

__init__: Konstruktor zum Initialisieren der Einkaufsliste.
zeige_menü: Methode zur Anzeige des Hauptmenüs.
artikel_anzeigen: Zeigt die Artikel der Liste an.
artikel_hinzufügen: Fügt einen neuen Artikel zur Liste hinzu.
artikel_bearbeiten: Bearbeitet die Menge des Artikels.
artikel_entfernen: Entfernt Artikel aus der Liste.
artikel_sortieren: Sortiert die Artikel alphabetisch.
einkaufsliste_leeren: Leert die gesamte Einkaufsliste.
statistik_anzeigen: Zeigt Statistiken zur Einkaufsliste an.
artikel_suchen: Sucht nach Artikeln in der Liste.

Die Einkaufsliste wird in einer JSON-Datei gespeichert und beim Start des Programms geladen. 
Farbausgaben in der Konsole werden durch das colorama-Modul unterstützt, um wichtige Informationen hervorzuheben und die Benutzerfreundlichkeit zu steigern.
'''

# Importiert das JSON-Modul für die Arbeit mit JSON-Dateien
import json
# Importiert das colorama-Modul für Farbausgaben in der Konsole
from colorama import Fore, Style, init

# Initialize colorama für farbige Konsolenausgabe
init(autoreset=True)

class EinkaufslisteBasis:
    def __init__(self):
        # Konstruktor der Klasse. Wird aufgerufen, wenn eine Instanz erstellt wird.
        # Lädt die Einkaufsliste von einer JSON-Datei
        self.artikel_liste = self.lade_einkaufsliste()

    def artikel_anzeigen(self):
        # Definiert Unterstreichung und Reset-Styles für die Terminalausgabe
        underline = '\033[4m'	# ANSI-Code für Unterstreichung
        reset = '\033[0m'		# ANSI-Code zum Zurücksetzen der Formatierung

        # Überprüft, ob die Einkaufsliste leer ist und gibt eine entsprechende Nachricht aus
        if not self.artikel_liste:
		    # Wenn die Liste leer ist, gibt eine entsprechende Nachricht aus
            print(f"{Fore.YELLOW}{underline}Die Einkaufsliste ist leer.{reset}{Style.RESET_ALL}\n")
        else:
            # Gibt die aktuelle Einkaufsliste mit Formatierung aus
            print("\n************************************")
            print(f"{Fore.GREEN}{underline}Aktuelle Einkaufsliste:{reset}{Style.RESET_ALL}")
            for i, item in enumerate(self.artikel_liste, start=1):
			    # Durchläuft alle Artikel und zeigt sie an
                print(f"{Fore.CYAN}{i}. {item['artikel']} - Menge: {item['menge']}{Style.RESET_ALL}")
            print("************************************")

    def artikel_hinzufügen(self):
	    # Fügt einen neuen Artikel zur Einkaufsliste hinzu
        try:
            # Fragt den Benutzer nach dem Namen des Artikels und der Menge
            artikel = input("Geben Sie den Namen des Artikels ein, den Sie hinzufügen möchten: ")
            menge = int(input(f"Geben Sie die Menge für {artikel} ein: "))

            # Überprüft, ob der Artikel bereits in der Liste existiert
            artikel_vorhanden = False
            for item in self.artikel_liste:
			    # Falls der Artikel schon vorhanden ist, wird die Menge erhöht
                if item['artikel'] == artikel:
                    item['menge'] += menge
                    artikel_vorhanden = True
                    print(f"{Fore.GREEN}{artikel} Menge wurde auf {item['menge']} aktualisiert.{Style.RESET_ALL}\n")
                    break

            # Falls der Artikel nicht existiert, wird er als neuer Eintrag hinzugefügt
            if not artikel_vorhanden:
                self.artikel_liste.append({'artikel': artikel, 'menge': menge})
                print(f"{Fore.GREEN}{artikel} mit Menge {menge} wurde zur Einkaufsliste hinzugefügt.{Style.RESET_ALL}\n")

            # Speichert die aktualisierte Einkaufsliste
            self.speichere_einkaufsliste()
        except ValueError:
		    # Falls die Eingabe der Menge keine gültige Zahl ist, wird eine Fehlermeldung ausgegeben
            print("Fehler: Bitte geben Sie eine gültige Zahl für die Menge ein.\n")
        except Exception as e:
		    # Allgemeine Fehlerbehandlung
            print(f"Fehler beim Hinzufügen des Artikels: {e}\n")

    def artikel_bearbeiten(self):
	    # Passt die Menge eines bestehenden Artikel in der Einkaufsliste an
        try:
            # Zeigt die aktuelle Einkaufsliste an
            self.artikel_anzeigen()
            if self.artikel_liste:
                # Fragt den Benutzer nach der Nummer des Artikels, den er bearbeiten möchte
                artikel_nr = int(input("Geben Sie die Nummer des Artikels ein, den Sie bearbeiten möchten: "))
                if 0 < artikel_nr <= len(self.artikel_liste):
                    artikel = self.artikel_liste[artikel_nr - 1]
                    # Fragt nach der neuen Menge
                    neue_menge = int(input(f"Geben Sie die neue Menge für {artikel['artikel']} ein (aktuell {artikel['menge']}): "))
                    artikel['menge'] = neue_menge
                    print(f"{Fore.GREEN}Menge von {artikel['artikel']} wurde auf {artikel['menge']} aktualisiert.{Style.RESET_ALL}\n")
                    # Speichert die aktualisierte Einkaufsliste
                    self.speichere_einkaufsliste()
                else:
				    # Wenn die Nummer ungültig ist, wird eine Fehlermeldung ausgegeben
                    print("Ungültige Nummer.\n")
        except ValueError:
		    # Fehlerbehandlung für ungültige Eingaben
            print("Fehler: Bitte geben Sie eine gültige Nummer ein.\n")
        except Exception as e:
		    # Allgemeine Fehlerbehandlung
            print(f"Fehler beim Bearbeiten des Artikels: {e}\n")

    def artikel_entfernen(self):
	     # Entfernt einen Artikel aus der Einkaufsliste
        try:
            # Zeigt die aktuelle Einkaufsliste an
            self.artikel_anzeigen()
            if self.artikel_liste:
                # Fragt den Benutzer nach der Nummer des Artikels, den er entfernen möchte
                artikel_nr = int(input("Geben Sie die Nummer des Artikels ein, den Sie entfernen möchten: "))
                if 0 < artikel_nr <= len(self.artikel_liste):
				    # Stellt sicher, dass die Nummer innerhalb des gültigen Bereichs liegt
                    entferntes_artikel = self.artikel_liste.pop(artikel_nr - 1)
                    print(f"{Fore.RED}{entferntes_artikel['artikel']} wurde aus der Einkaufsliste entfernt.{Style.RESET_ALL}\n")
                    # Speichert die aktualisierte Einkaufsliste
                    self.speichere_einkaufsliste()
                else:
				    # Wenn die Nummer ungültig ist, wird eine Fehlermeldung ausgegeben
                    print("Ungültige Nummer.\n")
        except ValueError:
		    # Fehlerbehandlung für ungültige Eingaben
            print("Fehler: Bitte geben Sie eine gültige Nummer ein.\n")
			# Allgemeine Fehlerbehandlung
        except Exception as e:
            print(f"Fehler beim Entfernen des Artikels: {e}\n")

    def lade_einkaufsliste(self):
	    # Lädt die Einkaufsliste von der JSON-Datei
        try:
            # Lädt die Einkaufsliste aus einer JSON-Datei
            with open('einkaufsliste.json', 'r') as file:
			    # Versucht, die Datei im Lese-Modus zu öffnen
                return json.load(file)
        except FileNotFoundError:
		    # Falls die Datei nicht existiert, wird eine leere Liste zurückgegeben
            return []
        except json.JSONDecodeError:
		    # Falls die Datei keine gültige JSON enthält, wird eine leere Liste zurückgegeben
            print("Fehler beim Lesen der JSON-Datei. Datei möglicherweise beschädigt oder leer.")
            return []

    def speichere_einkaufsliste(self):
	     # Speichert die Einkaufsliste in einer JSON-Datei
        try:
            # Speichert die Einkaufsliste in einer JSON-Datei
            with open('einkaufsliste.json', 'w') as file:
			    # Versucht, die Datei im Schreib-Modus zu öffnen
                json.dump(self.artikel_liste, file, indent=4)
        except Exception as e:
		    # Allgemeine Fehlerbehandlung für das Speichern der Datei
            print(f"Fehler beim Speichern der JSON-Datei: {e}")

class ErweiterteEinkaufsliste(EinkaufslisteBasis):
    def zeige_menü(self):
        # Zeigt die Menüoptionen für die Einkaufsliste an
        print("\nEinkaufsliste Menü:")
        print("1. Artikel anzeigen")
        print("2. Artikel hinzufügen")
        print("3. Artikel bearbeiten")
        print("4. Artikel entfernen")
        print("5. Liste sortieren")
        print("6. Einkaufsliste leeren")
        print("7. Statistik anzeigen")
        print("8. Artikel suchen")
        print("9. Beenden\n")

    def artikel_sortieren(self):
        # Definiert eine Funktion zum Sortieren der Artikelliste alphabetisch
        def sortiere_liste(liste):
		    # Implementierung des Bubble Sort Algorithmus zur Sortierung
            n = len(liste)
            for i in range(n):
                for j in range(0, n-i-1):
                    if liste[j]['artikel'] > liste[j+1]['artikel']:
					    # Vergleicht benachbarte Elemente und tauscht sie falls notwendig
                        liste[j], liste[j+1] = liste[j+1], liste[j]

        # Sortiert die Artikelliste und speichert sie
        sortiere_liste(self.artikel_liste)
        print(f"{Fore.YELLOW}Einkaufsliste wurde alphabetisch sortiert.{Style.RESET_ALL}\n")
        self.speichere_einkaufsliste()

    def einkaufsliste_leeren(self):
        # Leert die Einkaufsliste und speichert sie
        self.artikel_liste.clear()
        print(f"{Fore.RED}Einkaufsliste wurde geleert.{Style.RESET_ALL}\n")
        self.speichere_einkaufsliste()

    def statistik_anzeigen(self):
        # Definiert eine Funktion zum Finden des Artikels mit der maximalen Menge
        def finde_max_menge(liste):
            max_item = liste[0]
            for item in liste[1:]:
                if item['menge'] > max_item['menge']:
				    # Aktualisiert max_item wenn ein Artikel mit höherer Menge gefunden wird
                    max_item = item
            return max_item

        # Definiert eine Funktion zum Finden des Artikels mit der minimalen Menge
        def finde_min_menge(liste):
            min_item = liste[0]
            for item in liste[1:]:
                if item['menge'] < min_item['menge']:
				    # Aktualisiert min_item wenn ein Artikel mit niedrigerer Menge gefunden wird
                    min_item = item
            return min_item

        # Überprüft, ob die Einkaufsliste leer ist, und gibt entsprechende Statistiken aus
        if not self.artikel_liste:
		     # Wenn die Liste leer ist, gibt eine entsprechende Nachricht aus
            print(f"{Fore.YELLOW}Die Einkaufsliste ist leer.{Style.RESET_ALL}\n")
        else:
		     # Wenn die Liste nicht leer ist, zeigt die Statistik an
            gesamtanzahl = len(self.artikel_liste)
            max_artikel = finde_max_menge(self.artikel_liste)
            min_artikel = finde_min_menge(self.artikel_liste)

            # Gibt die Statistiken der Einkaufsliste aus
            print(f"{Fore.GREEN}Statistik:{Style.RESET_ALL}")
            print(f"{Fore.CYAN}Gesamtanzahl der Artikel: {gesamtanzahl}{Style.RESET_ALL}")
            print(f"{Fore.CYAN}Artikel mit der höchsten Menge: {max_artikel['artikel']} ({max_artikel['menge']}){Style.RESET_ALL}")
            print(f"{Fore.CYAN}Artikel mit der niedrigsten Menge: {min_artikel['artikel']} ({min_artikel['menge']}){Style.RESET_ALL}\n")

    def artikel_suchen(self):
	    # Sucht nach Artikeln, die einen bestimmten Suchbegriff enthalten
        # Fragt den Benutzer nach einem Suchbegriff
        suchbegriff = input("Geben Sie einen Suchbegriff ein: ")
        gefundene_artikel = [item for item in self.artikel_liste if suchbegriff.lower() in item['artikel'].lower()]

        # Zeigt die Suchergebnisse an
        if nicht gefundene_artikel:
		    # Gibt eine Nachricht aus, wenn keine Artikel gefunden wurden
            print(f"{Fore.YELLOW}Keine Artikel gefunden, die '{suchbegriff}' enthalten.{Style.RESET_ALL}\n")
        else:
		    # Gibt die gefundenen Artikel aus
            print(f"{Fore.GREEN}Gefundene Artikel:{Style.RESET_ALL}")
            for i, item in enumerate(gefundene_artikel, start=1):
                print(f"{Fore.CYAN}{i}. {item['artikel']} - Menge: {item['menge']}{Style.RESET_ALL}")
            print("\n")

def main():
    # Hauptfunktion zur Steuerung des Programms
    # Erstellt eine Instanz der abgeleiteten Klasse
    einkaufsliste = ErweiterteEinkaufsliste()

    while True:
        # Zeigt das Menü an und fragt den Benutzer nach der Auswahl
        einkaufsliste.zeige_menü()
        auswahl = input("Wählen Sie eine Option (1-9): ")

        if auswahl == '1':
            einkaufsliste.artikel_anzeigen()
        elif auswahl == '2':
            einkaufsliste.artikel_hinzufügen()
        elif auswahl == '3':
            einkaufsliste.artikel_bearbeiten()
        elif auswahl == '4':
            einkaufsliste.artikel_entfernen()
        elif auswahl == '5':
            einkaufsliste.artikel_sortieren()
        elif auswahl == '6':
            einkaufsliste.einkaufsliste_leeren()
        elif auswahl == '7':
            einkaufsliste.statistik_anzeigen()
        elif auswahl == '8':
            einkaufsliste.artikel_suchen()
        elif auswahl == '9':
            print("Programm beendet.")
            break
        else:
            print("Ungültige Auswahl. Bitte versuchen Sie es erneut.\n")

# Startet das Programm, wenn dieses Skript direkt ausgeführt wird
if __name__ == "__main__":
    main()

